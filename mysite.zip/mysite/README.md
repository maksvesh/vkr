# mysite — Django проект

## Запуск

```bash
pip install django
cd mysite
python manage.py migrate
python manage.py runserver
```

Открыть: http://127.0.0.1:8000

## Страницы

| URL         | Страница             |
|-------------|----------------------|
| /           | О нас                |
| /catalog/   | Каталог              |
| /login/     | Вход                 |
| /register/  | Регистрация          |
| /profile/   | Профиль (только авт.)|

## Структура

```
mysite/
├── config/          # настройки проекта
├── main/
│   ├── static/css/style.css   # ← весь CSS здесь
│   ├── templates/main/        # шаблоны
│   ├── views.py
│   └── urls.py
└── manage.py
```
