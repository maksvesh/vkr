
Установка:

pip install django

Запуск:

python manage.py migrate
python manage.py createsuperuser
python manage.py runserver

Админка:
http://127.0.0.1:8000/admin
