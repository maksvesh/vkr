
from django.contrib import admin
from django.urls import path
from main import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index),
    path('login/', views.login_page),
    path('register/', views.register_page),
    path('profile/', views.profile),
]
